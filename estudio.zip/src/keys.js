module.exports={
  database:{
    host:'localhost',
    user:'c2161585_estudio',
    password:'78RInufore',
    database:'c2161585_estudio',
    ssl: true
  }
};

